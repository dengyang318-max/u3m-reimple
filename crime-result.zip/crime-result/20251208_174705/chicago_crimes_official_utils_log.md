# Chicago Crimes Official-Utils Experiment (20251208_174705)

Loading Chicago Crimes dataset (official-port experiment)...
No --csv-path provided. Downloading Chicago Crimes dataset via kagglehub...
Using dataset file: C:\Users\james\.cache\kagglehub\datasets\currie32\crimes-in-chicago\versions\1\Chicago_Crimes_2012_to_2017.csv
Loaded dataset with shape: (510372, 27)
Primary point set shape: (500, 2)
Rotated point set shape: (500, 2)

Visualizing primary and rotated point sets (official utils)...
![official_utils point sets](official_utils_point_sets.png)

Running ray-sweeping (official vs official-style)...
Total time (official-style): 2.2177 s

Top-k high-skew directions (official port on rotated set):
| Rank | Direction (x, y) | Skew |
|------|------------------|------|
| 1 | (0.993572, 0.006428) | 0.267657 |
| 2 | (0.748931, 0.251069) | 0.216176 |
| 3 | (0.570227, 0.429773) | 0.112962 |
| 4 | (0.221478, 0.778522) | 0.029930 |
| 5 | (0.402659, 0.597341) | 0.023164 |

[Official port] Visualizing tail and density along top-1 direction (skew=0.267657)...

Using reimplemented top direction for visualization.

Validation: skew along chosen direction f is -0.058958
![official_utils_top1 full](official_utils_top1_full.png)
Tail subset shape (q=0.01): (5104, 27)
![official_utils_top1 tail](official_utils_top1_tail.png)
![official_utils_top1 density](official_utils_top1_density.png)

=== Global vs Tail statistics (Chicago Crimes) ===
| Metric                             | Global | Tail |
|------------------------------------|:------:|:----:|
| Positive rate (Arrest=1)          | 0.228 | 0.214 |
| Accuracy (Logistic Regression)    | 0.799 | 0.788 |
| F1 (Logistic Regression)          | 0.330 | 0.216 |

=== Multi-Percentile Evaluation Table (Chicago Crimes, full dataset) ===
| Percentile | PosRate_tail | Accuracy | F1-score |
|-----------:|-------------:|---------:|---------:|
|    1.00000 |       0.228 |    0.799 |    0.330 |
|    0.10000 |       0.214 |    0.796 |    0.228 |
|    0.01000 |       0.214 |    0.788 |    0.216 |
|    0.00100 |       0.170 |    0.810 |    0.198 |
|    0.00010 |       0.255 |    0.745 |    0.250 |

[Official port] Visualizing tail and density along top-2 direction (skew=0.216176)...

Using reimplemented top direction for visualization.

Validation: skew along chosen direction f is -0.011870
![official_utils_top2 full](official_utils_top2_full.png)
Tail subset shape (q=0.01): (5103, 27)
![official_utils_top2 tail](official_utils_top2_tail.png)
![official_utils_top2 density](official_utils_top2_density.png)

=== Global vs Tail statistics (Chicago Crimes) ===
| Metric                             | Global | Tail |
|------------------------------------|:------:|:----:|
| Positive rate (Arrest=1)          | 0.228 | 0.252 |
| Accuracy (Logistic Regression)    | 0.799 | 0.761 |
| F1 (Logistic Regression)          | 0.330 | 0.240 |

=== Multi-Percentile Evaluation Table (Chicago Crimes, full dataset) ===
| Percentile | PosRate_tail | Accuracy | F1-score |
|-----------:|-------------:|---------:|---------:|
|    1.00000 |       0.228 |    0.799 |    0.330 |
|    0.10000 |       0.202 |    0.807 |    0.205 |
|    0.01000 |       0.252 |    0.761 |    0.240 |
|    0.00100 |       0.236 |    0.768 |    0.224 |
|    0.00010 |       0.277 |    0.745 |    0.400 |

[Official port] Visualizing tail and density along top-3 direction (skew=0.112962)...

Using reimplemented top direction for visualization.

Validation: skew along chosen direction f is 0.118742
![official_utils_top3 full](official_utils_top3_full.png)
Tail subset shape (q=0.01): (5104, 27)
![official_utils_top3 tail](official_utils_top3_tail.png)
![official_utils_top3 density](official_utils_top3_density.png)

=== Global vs Tail statistics (Chicago Crimes) ===
| Metric                             | Global | Tail |
|------------------------------------|:------:|:----:|
| Positive rate (Arrest=1)          | 0.228 | 0.207 |
| Accuracy (Logistic Regression)    | 0.799 | 0.788 |
| F1 (Logistic Regression)          | 0.330 | 0.233 |

=== Multi-Percentile Evaluation Table (Chicago Crimes, full dataset) ===
| Percentile | PosRate_tail | Accuracy | F1-score |
|-----------:|-------------:|---------:|---------:|
|    1.00000 |       0.228 |    0.799 |    0.330 |
|    0.10000 |       0.200 |    0.811 |    0.332 |
|    0.01000 |       0.207 |    0.788 |    0.233 |
|    0.00100 |       0.114 |    0.871 |    0.298 |
|    0.00010 |       0.058 |    0.885 |    0.000 |
