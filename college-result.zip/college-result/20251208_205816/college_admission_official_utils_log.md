# College Admission Official-Utils Experiment (20251208_205816)

Loading College Admission dataset...
No --excel-path provided. Downloading College Admission dataset via kagglehub...
Using dataset file: C:\Users\james\.cache\kagglehub\datasets\eswarchandt\admission\versions\1\Admission.xlsx
Loaded dataset with shape: (400, 7)
Primary point set shape: (400, 2)
Rotated point set shape: (400, 2)

Visualizing primary and rotated point sets...
![official_utils point sets](official_utils_point_sets.png)

Running ray-sweeping...
Total time (official): 2.1085 s

Top-k high-skew directions:
| Rank | Direction (x, y) | Skew |
|------|------------------|------|
| 1 | (0.274721, 0.961524) | 0.054339 |
| 2 | (0.791590, 0.611052) | 0.049722 |
| 3 | (0.563337, 0.826227) | 0.039654 |
| 4 | (0.942627, 0.333847) | 0.022658 |
| 5 | (0.999829, 0.018515) | 0.007281 |

Visualizing top-1 direction (skew=0.054339)...

Using reimplemented top direction for visualization.

Validation: skew along chosen direction f is -0.014855
![official_utils_top1 full](official_utils_top1_full.png)
Tail subset shape (q=0.1): (40, 7)

=== Global vs Tail statistics (College Admission) ===
| Metric                             | Global | Tail |
|------------------------------------|:------:|:----:|
| Positive rate (admit=1)           | 0.318 | 0.400 |
| Accuracy (Logistic Regression)    | 0.713 | 0.575 |
| F1 (Logistic Regression)          | 0.320 | 0.452 |

=== Multi-Percentile Evaluation Table ===
| Percentile | Accuracy | F1-score | F/M ratio |
|-----------:|---------:|---------:|----------:|
|       1.00 |    0.712 |    0.320 |    1.111 |
|       0.50 |    0.640 |    0.400 |    1.174 |
|       0.20 |    0.650 |    0.481 |    0.905 |
|       0.10 |    0.575 |    0.452 |    0.739 |
|       0.08 |    0.625 |    0.538 |    0.684 |
|       0.04 |    0.625 |    0.625 |    1.000 |
![official_utils_top1 tail](official_utils_top1_tail.png)
![official_utils_top1 density](official_utils_top1_density.png)

Visualizing top-2 direction (skew=0.049722)...

Using reimplemented top direction for visualization.

Validation: skew along chosen direction f is -0.048324
![official_utils_top2 full](official_utils_top2_full.png)
Tail subset shape (q=0.1): (40, 7)

=== Global vs Tail statistics (College Admission) ===
| Metric                             | Global | Tail |
|------------------------------------|:------:|:----:|
| Positive rate (admit=1)           | 0.318 | 0.425 |
| Accuracy (Logistic Regression)    | 0.713 | 0.650 |
| F1 (Logistic Regression)          | 0.320 | 0.562 |

=== Multi-Percentile Evaluation Table ===
| Percentile | Accuracy | F1-score | F/M ratio |
|-----------:|---------:|---------:|----------:|
|       1.00 |    0.712 |    0.320 |    1.111 |
|       0.50 |    0.650 |    0.407 |    1.273 |
|       0.20 |    0.620 |    0.483 |    0.927 |
|       0.10 |    0.650 |    0.562 |    1.105 |
|       0.08 |    0.625 |    0.571 |    1.000 |
|       0.04 |    0.562 |    0.533 |    1.286 |
![official_utils_top2 tail](official_utils_top2_tail.png)
![official_utils_top2 density](official_utils_top2_density.png)

Visualizing top-3 direction (skew=0.039654)...

Using reimplemented top direction for visualization.

Validation: skew along chosen direction f is -0.004881
![official_utils_top3 full](official_utils_top3_full.png)
Tail subset shape (q=0.1): (39, 7)

=== Global vs Tail statistics (College Admission) ===
| Metric                             | Global | Tail |
|------------------------------------|:------:|:----:|
| Positive rate (admit=1)           | 0.318 | 0.436 |
| Accuracy (Logistic Regression)    | 0.713 | 0.590 |
| F1 (Logistic Regression)          | 0.320 | 0.529 |

=== Multi-Percentile Evaluation Table ===
| Percentile | Accuracy | F1-score | F/M ratio |
|-----------:|---------:|---------:|----------:|
|       1.00 |    0.712 |    0.320 |    1.111 |
|       0.50 |    0.638 |    0.400 |    1.261 |
|       0.20 |    0.650 |    0.517 |    0.951 |
|       0.10 |    0.590 |    0.529 |    0.696 |
|       0.08 |    0.562 |    0.500 |    0.882 |
|       0.04 |    0.533 |    0.462 |    1.500 |
![official_utils_top3 tail](official_utils_top3_tail.png)
![official_utils_top3 density](official_utils_top3_density.png)
